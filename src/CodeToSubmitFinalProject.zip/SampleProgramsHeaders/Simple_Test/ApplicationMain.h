/*
 * program.h
 *
 *  Created on: Dec 13, 2024
 *      Author: Alek
 */

#ifndef INC_SAMPLEPROGRAMS_SIMPLE_TEST_APPLICATIONMAIN_H_
#define INC_SAMPLEPROGRAMS_SIMPLE_TEST_APPLICATIONMAIN_H_

#include "init.h"

void appFrame(void * arg);
void mult2(uint32_t * a);


#endif /* INC_SAMPLEPROGRAMS_SIMPLE_TEST_APPLICATIONMAIN_H_ */
