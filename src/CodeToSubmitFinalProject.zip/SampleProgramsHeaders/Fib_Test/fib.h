/*
 * fib.h
 *
 *  Created on: Dec 19, 2024
 *      Author: Alek
 */

#ifndef INC_SAMPLEPROGRAMS_FIB_TEST_FIB_H_
#define INC_SAMPLEPROGRAMS_FIB_TEST_FIB_H_

#include "init.h"

void fib(void * fibNum);

#endif /* INC_SAMPLEPROGRAMS_FIB_TEST_FIB_H_ */
