/*
 * Check1.h
 *
 *  Created on: Dec 19, 2024
 *      Author: hoppeb
 */

#ifndef CHECK_1
#define CHECK_1

#include "init.h"

void checkapp(void *i);

#endif
